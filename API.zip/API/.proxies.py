import time
import subprocess

def run_script():
    try:
        subprocess.run(['python3', '.scrape.py'])
    except Exception as e:
        print(f"Error while running script: {e}")

while True:
    print("Running proxies scrape")
    run_script()  # Menjalankan skrip
    print("Waited 1 hour to run again...")
    time.sleep(3600)